import React, { useEffect, useState } from 'react';
import CardItems from '../components/CardItems';
import Navbar from '../components/NavBar';
import api from '../pages/api'; 
import 'bootstrap/dist/css/bootstrap.min.css';

function Home() {
  const [productsByCategory, setProductsByCategory] = useState({});
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await api.get('/inventory/all');
        const products = response.data;

        const categorizedProducts = {};
        products.forEach((product) => {
          const category = product.category || 'Uncategorized';
          if (!categorizedProducts[category]) {
            categorizedProducts[category] = [];
          }
          categorizedProducts[category].push(product);
        });
        
        setProductsByCategory(categorizedProducts);
      } catch (error) {
        if(error.response)
          console.error(error.response.data);
      }
    };

    fetchProducts();
  }, []);

  
  const filteredProductsByCategory = Object.keys(productsByCategory).reduce(
    (acc, category) => {
      const filteredProducts = productsByCategory[category].filter((product) =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      
      if (filteredProducts.length > 0) {
        acc[category] = filteredProducts;
      }
      return acc;
    },
    {}
  );

  return (
    <>
      <Navbar />
      <div className="container mt-4">
        <div className="mb-4">
          <input
            type="text"
            className="form-control"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <h1 className="text-center">Products</h1>
        {Object.keys(filteredProductsByCategory).map((category) => (
          <div key={category} className="category-section mb-5">
            <h3 className="mb-4">{category}</h3>
            <div className="row g-4">
              {filteredProductsByCategory[category].map((product) => (
                <div key={product.id} className="col-lg-4 col-md-6 col-sm-12">
                  <CardItems product={product} />
                </div>
              ))}
            </div>
          </div>
        ))}
        
        {Object.keys(filteredProductsByCategory).length === 0 && (
          <div className="text-center mt-4">
            <p>No products found matching your search.</p>
          </div>
        )}
      </div>
    </>
  );
}

export default Home;
