import React, { useEffect, useState } from 'react';
import CartItems from '../components/HistoryCard';
import Navbar from '../components/NavBar';
import api from '../pages/api'; 
import 'bootstrap/dist/css/bootstrap.min.css';

function OrderHistory() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrderHistory = async () => {
      const userId = localStorage.getItem('userId');
      try {
        const response = await api.get(`/orders/byuserId/${userId}`);
        setOrders(response.data);
      } catch (error) {
        console.error('Error fetching order history:', error);
      }
    };

    fetchOrderHistory();
  }, []);

  return (
    <>
      <Navbar />
      <div className='container'>
        <h1 className='text-center'>History</h1>
        <div>
          <div className='row row-cols-1 row-cols-md-2 g-4'>
            {orders.map((order) => (
              <CartItems key={order.id} order={order} />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default OrderHistory;
