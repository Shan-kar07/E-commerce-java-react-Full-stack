import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../pages/api'; 
import Navbar from '../components/NavBar';
import DataTable from '../components/DataTable';
import 'bootstrap/dist/css/bootstrap.min.css';

const PaymentPage = () => {
    const [data, setData] = useState([]);
    const [amount, setAmount] = useState(0);
    const [paymentMethod, setPaymentMethod] = useState('');
    const userId = localStorage.getItem('userId');
    const navigate = useNavigate();

    useEffect(() => {
        // Fetch order data
        api.get(`/orders/ordercart/${userId}`)
            .then(response => {
                setData(response.data);
            })
            .catch(error => {
                console.error(error.response.data);
            });

        // Fetch payment amount
        api.post(`/orders/makePayment/${userId}`)
            .then(response => {
                setAmount(response.data);
            })
            .catch(error => {
                console.error(error.response.data);
            });
    }, [userId]);

    const handlePayment = () => {
        const statusPayload = "COMPLETED";

        if (paymentMethod === 'COD' || paymentMethod === 'CARD') {
            api.put(`/payments/${userId}/status`, statusPayload, {
                    headers: { 'Content-Type': 'application/json' }
                })
                .then(response => {
                    alert('Payment Successful');
                    navigate('/home'); 
                })
                .catch(error => {
                    console.error(error.response.data);
                });
        } else {
            const failedPayload = "FAILED";

            api.put(`/payments/${userId}/status`, failedPayload, {
                    headers: { 'Content-Type': 'application/json' }
                })
                .then(response => {
                    alert('Payment Failed');
                    navigate('/home'); 
                })
                .catch(error => {
                    console.error(error.response.data);
                });
        }
    };

    return (
        <div>
            <Navbar/>
            <DataTable data={data}/>
            <div className="mx-5 mt-3">
                <h3>Amount to be paid: ₹{amount}</h3>
            </div>
            <input 
                type='text' 
                placeholder='COD or CARD' 
                className='form-control mx-5 mt-3'
                style={{width:"300px"}} 
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
            />
            <div>
                <button 
                    type="button" 
                    className="btn btn-success mx-5 mt-3" 
                    onClick={handlePayment}
                >
                    Pay
                </button>
            </div>
        </div>
    );
}

export default PaymentPage;
