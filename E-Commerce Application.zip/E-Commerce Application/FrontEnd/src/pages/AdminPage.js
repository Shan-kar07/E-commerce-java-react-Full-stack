import React, { useState, useEffect } from 'react';
import api from './api';
import 'bootstrap/dist/css/bootstrap.min.css';

function AdminPage() {
  
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    category: '',
    stockLevel: '',
  });

  
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      
      const response = await api.get('http://localhost:8080/inventory/all');
      setProducts(response.data);
    } catch (err) {
      setError('Failed to load products');
    }
  };

  
  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      await api.post('http://localhost:8080/inventory/putproduct', newProduct);
      fetchProducts(); 
      setNewProduct({
        name: '',
        price: '',
        category: '',
        stockLevel: '',
      });
    } catch (err) {
      setError('Failed to add product');
    }
  };

  
  const handleUpdateStock = async (productId, newQuantity) => {
    try {
      await api.put(`http://localhost:8080/inventory/product/${productId}/update-stockup?quantity=${newQuantity}`);
      fetchProducts();
    } catch (err) {
      setError('Failed to update product stock');
    }
  };

  
  const handleDeleteProduct = async (inventoryId) => {
    try {
      await api.delete(`http://localhost:8080/inventory/product/${inventoryId}`);
      fetchProducts();
    } catch (err) {
      console.error(err);
      setError('Failed to delete product');
    }
  };

  return (
    <div className="container my-5">
      <h1 style={{textAlign:"center"}}>Admin Panel</h1>
      <h2>Add Products</h2>
      {error && <div className="alert alert-success">{error}</div>}

      

      <form onSubmit={handleAddProduct} className="mb-4">
        <div className="row mb-3">
          <div className="col">
            <input
              type="text"
              className="form-control"
              placeholder="Product Name"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              required
            />
          </div>
          <div className="col">
            <input
              type="number"
              className="form-control"
              placeholder="Price"
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
              required
            />
          </div>
        </div>
        <div className="row mb-3">
          <div className="col">
            <input
              type="text"
              className="form-control"
              placeholder="Category"
              value={newProduct.category}
              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              required
            />
          </div>
          <div className="col">
            <input
              type="number"
              className="form-control"
              placeholder="Stock Level"
              value={newProduct.stockLevel}
              onChange={(e) => setNewProduct({ ...newProduct, stockLevel: e.target.value })}
              required
            />
          </div>
        </div>
        <button type="submit" className="btn btn-primary">Add Product</button>
      </form>

      <hr />

      
      <h3 className="mt-4">Product List</h3>
      <div className="table-responsive">
        <table className="table table-striped table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>Inventory ID</th>
              <th>Product ID</th>
              <th>Name</th>
              <th>Price</th>
              <th>Category</th>
              <th>Stock Level</th>
              <th>Update Stock</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.productId}</td>
                <td>{product.name}</td>
                <td>{product.price}</td>
                <td>{product.category}</td>
                <td>{product.stockLevel}</td>
                <td>
                  <UpdateStockField product={product} onUpdateStock={handleUpdateStock} />
                </td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDeleteProduct(product.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const UpdateStockField = ({ product, onUpdateStock }) => {
  const [quantity, setQuantity] = useState('');
  return (
    <div className="d-flex">
      <input
        type="number"
        className="form-control form-control-sm"
        placeholder="New Qty"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        style={{ width: '80px' }}
      />
      <button
        className="btn btn-success btn-sm ms-2"
        onClick={() => {
          if (quantity) {
            onUpdateStock(product.productId, quantity);
            setQuantity('');
          }
        }}
      >
        Update
      </button>
    </div>
  );
};

export default AdminPage;
