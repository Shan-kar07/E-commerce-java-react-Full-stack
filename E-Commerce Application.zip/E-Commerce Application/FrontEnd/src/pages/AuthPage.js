import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';

function AuthLandingPage() {
  return (
    <>
    <div
      className="container-fluid vh-100 d-flex align-items-center justify-content-center"
      style={{ backgroundColor: '#f8f9fa' }}
    >
      <div
        className="card text-center shadow p-5"
        style={{ maxWidth: '600px', borderRadius: '20px' }}
      >
        <h1 className="mb-4">Welcome to E-Commerce Platform</h1>
        <p className="mb-5">Sign In or Sign Up to your E-Commerce Platform</p>
        <div className="row">
          <div className="col-xs-12 col-md-6 mb-3 mb-md-0">
            <Link to='/login'>
              <button
                className="btn btn-primary btn-lg w-100"
              >
                Sign In
              </button>
            </Link>
          </div>
          <div className="col-xs-12 col-md-6">
            <Link to='/register'>
              <button
                className="btn btn-success btn-lg w-100"
              >
                Sign Up
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
    <Footer/>
    </>
  );
}

export default AuthLandingPage;
