import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Signup() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const validateEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    };

    const validatePassword = (password) => {
        const re = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
        return re.test(String(password));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        const userData = {
            name: name,
            email: email,
            password: password,
            roles: 'USER'
        };

        let validationErrors = {};

        if (!validateEmail(email)) {
            validationErrors.email = 'Invalid email address';
        }

        if (!validatePassword(password)) {
            validationErrors.password = 'Password must be at least 8 characters long and include one special character and some digits';
        }

        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }

        try {
            const response = await axios.post('http://localhost:8080/auth/new', userData);
            console.log('Response:', response.data);
            if(response.data==='This UserName is Already Registered.'){
                alert('This UserName is Already Registered.Try with other username')
                navigate('/register')
            }else{navigate('/login');}
            if(response.status==='403'){navigate('/*')}
            
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <>
            <div>
                <div className="container-fluid vh-75 d-flex align-items-center justify-content-center">
                    <div className="card text-black p-4" style={{ borderRadius: '25px', maxWidth: '500px', width: '100%' }}>
                        <div className="card-body">
                            <h1 className="text-center fw-bold mb-5 mt-4">Sign Up</h1>
                            <form onSubmit={handleSubmit}>

                                <div className="mb-4">
                                    <label htmlFor="formName" className="form-label">Your Name</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="formName"
                                        placeholder="Enter your name"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                    />
                                </div>

                                <div className="mb-4">
                                    <label htmlFor="formEmail" className="form-label">Your Email</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        id="formEmail"
                                        placeholder="Enter your email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                    {errors.email && <small className="text-danger">{errors.email}</small>}
                                </div>

                                <div className="mb-4">
                                    <label htmlFor="formPassword" className="form-label">Password</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        id="formPassword"
                                        placeholder="Enter your password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                    {errors.password && <small className="text-danger">{errors.password}</small>}
                                </div>

                                <button type="submit" className="btn btn-primary w-100 mb-4">Register</button>

                                <p className="text-center">
                                    Already have an account? <Link to="/login">Sign In</Link>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div className='mt-3'>
                <Footer />
            </div>
        </>
    );
}

export default Signup;
