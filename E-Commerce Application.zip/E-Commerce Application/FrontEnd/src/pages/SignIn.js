// SignIn.jsx
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';
import Footer from '../components/Footer';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

function SignIn() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const userData = {
      username: username,
      password: password,
    };

    try {
      const response = await axios.post('http://localhost:8080/auth/authenticate', userData);

      const { token, userId } = response.data;
    
      localStorage.setItem('jwtToken', token);
      localStorage.setItem('userId', userId);

      
      const decoded = jwtDecode(token);
      console.log('Decoded token:', decoded);

      if (decoded.roles && decoded.roles.toLowerCase() === 'admin') {
        
        navigate('/admin');
      } else {
        
        navigate('/home');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <>
      <div className="container-fluid vh-100 d-flex align-items-center justify-content-center">
        <div className="card text-black p-4" style={{ borderRadius: '50px', maxWidth: '400px', width: '100%' }}>
          <div className="card-body">
            <h1 className="text-center fw-bold mb-5">Sign In</h1>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
             
              <div className="mb-4">
                <label htmlFor="formUsername" className="form-label">Username</label>
                <input
                  type="text"
                  className="form-control"
                  id="formUsername"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="formPassword" className="form-label">Password</label>
                <input
                  type="password"
                  className="form-control"
                  id="formPassword"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <button type="submit" className="btn btn-primary w-100 mb-4">Sign In</button>
            </form>
            <p className="mt-3 text-center">
              Don't have an account? <a href="/register">Register here</a>
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default SignIn;
