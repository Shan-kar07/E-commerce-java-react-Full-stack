import React, { useEffect, useState } from 'react';
import CartCard from '../components/CartCard';
import Navbar from '../components/NavBar';
import { Link } from 'react-router-dom';
import api from '../pages/api'; 
import 'bootstrap/dist/css/bootstrap.min.css';

function CartPage() {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const fetchCartItems = async () => {
      const userId = localStorage.getItem('userId'); 

      try {
        const response = await api.get(`/orders/ordercart/${userId}`);
        setCartItems(response.data);
      } catch (error) {
        console.error('Error fetching cart items:', error);
      }
    };

    fetchCartItems();
  }, []);

  const handleQuantityChange = (productId, newQuantity) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.productId === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleDelete = (productId) => {
    setCartItems((prevItems) =>
      prevItems.filter((item) => item.productId !== productId)
    );
  };

  return (
    <>
      <Navbar />
      <div className="container">
        <h1 className="text-center fw-bold mb-3 mt-4">Cart</h1>
        {cartItems.length > 0 ? (
          <div className="row g-4">
            {cartItems.map((item) => (
              <CartCard
                key={item.id}
                item={item}
                onQuantityChange={handleQuantityChange}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <p className="text-center">Your cart is empty.</p>
        )}
        <Link to='/payment'>
          <button className="btn btn-success mx-5 my-1 mt-4">
            Make Payment
          </button>
        </Link>
      </div>
    </>
  );
}

export default CartPage;
