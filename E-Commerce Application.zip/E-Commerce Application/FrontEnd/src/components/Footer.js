import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <>
      <footer className="footer mt-auto py-4 bg-dark text-light rounded">
        <div className="container">
          <div className="row">
            {/* Column 1: About Section */}
            <div className="col-md-4 mb-3">
              <h5>About Us</h5>
              <p>
                We are a leading e-commerce platform offering a wide range of products to cater to all your needs. Our mission is to provide quality products with exceptional customer service.
              </p>
            </div>

            {/* Column 2: Navigation Links */}
            <div className="col-md-4 mb-3">
              <h5>Quick Links</h5>
              <ul className="list-unstyled">
                <li>
                  <Link to="/login" className="text-light">
                    Home
                  </Link>
                </li>
              </ul>
            </div>

            {/* Column 3: Contact Information */}
            <div className="col-md-4 mb-3">
              <h5>Contact Us</h5>
              <p>
                <i className="fas fa-map-marker-alt me-2"></i>
                123 Main Street, Anytown, USA
              </p>
              <p>
                <i className="fas fa-phone me-2"></i>
                +1 (555) 123-4567
              </p>
              <p>
                <i className="fas fa-envelope me-2"></i>
                support@example.com
              </p>
            </div>
          </div>
          <hr className="bg-light" />
          <div className="row d-flex justify-content-between">
            <div className="col-md-6">
              <p className="mb-0">
                &copy; {new Date().getFullYear()} E-commerce Application. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Footer;
