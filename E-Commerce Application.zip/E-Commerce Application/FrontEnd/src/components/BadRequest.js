import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function BadRequest() {
  return (
    <div className="container text-center mt-5">
      <h1 className="display-4">400 - Bad Request</h1>
      <p className="lead">
        The request could not be understood or was missing required parameters.
      </p>
      <hr />
      <p>Please verify your input or try again later.</p>
      <Link to="/home" className="btn btn-primary">
        Go Back Home
      </Link>
    </div>
  );
}

export default BadRequest;
