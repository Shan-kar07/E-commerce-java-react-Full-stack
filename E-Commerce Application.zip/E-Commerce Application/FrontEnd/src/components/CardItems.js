import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import api from '../pages/api'; // Axios instance with interceptor
import '../css/CardItems.css';
import { useNavigate } from 'react-router-dom';

function CardItems({ product }) {
  const [quantity, setQuantity] = useState(1);
  const navigate = useNavigate();

  const handleIncrement = () =>
    setQuantity((prev) => Math.min(prev + 1, product.stockLevel));

  const handleDecrement = () =>
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1));

  const handleAddToCart = async () => {
    const userId = localStorage.getItem('userId');

    
    try {
      const response = await api.get(`/orders/ordercart/${userId}`);
      const cartOrders = response.data;

     
      const productExistsInCart = cartOrders.some(
        (order) => order.productId === product.productId
      );
      if (productExistsInCart) {
        alert(
          `The ${product.name} is already present in the cart. Please update the quantity in Cart.`
        );
        navigate('/cart');
        return;
      }
    } catch (error) {
      if(error.response)
        console.error(error.response.data);
    }

    const orderData = {
      userId: userId,
      orderId: userId, // It appears orderId is set to userId. Adjust if needed.
      productId: product.productId,
      quantity: quantity,
      price: product.price,
      productName: product.name,
    };

    console.log('Order data being sent:', orderData);

    try {
      await api.post('/auth/useraddorder', orderData);
      alert(`Added ${quantity} of ${orderData.productName} to cart.`);
      navigate('/cart');
    } catch (error) {
      console.error('Error adding order to cart:', error);
      alert(
        `Error adding ${orderData.productName} to cart. Please try again later.`
      );
    }
  };

  return (
    <div className="card card-darkmode h-100">
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{product.name}</h5>
        <p className="card-text">Price: ₹{product.price}</p>
        <p className="card-text">
          Stock Level:{' '}
          {product.stockLevel <= 5 ? 'Very Few Left' : 'Available'}
        </p>
        <div className="mt-auto">
          {product.stockLevel > 0 ? (
            <>
              <div className="input-group mb-3" style={{ maxWidth: '150px' }}>
                <button
                  className="btn btn-light"
                  onClick={handleDecrement}
                  aria-label="Decrease quantity"
                >
                  -
                </button>
                <div className="input-group-text">{quantity}</div>
                <button
                  className="btn btn-light"
                  onClick={handleIncrement}
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>
              <button
                className="btn btn-light w-100 mt-2"
                onClick={handleAddToCart}
              >
                Add to Cart
              </button>
            </>
          ) : (
            <button className="btn btn-secondary w-100 mt-2" disabled>
              Out of Stock
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default CardItems;
