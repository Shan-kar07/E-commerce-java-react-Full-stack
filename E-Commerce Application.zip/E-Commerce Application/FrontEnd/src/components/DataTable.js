import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function DataTable({ data }) {
    return (
        <div className='mt-5 mx-5'>
            <table className="table table-striped table-bordered table-hover table-responsive">
                <thead className="table-dark">
                    <tr>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price Per Quantity X 1</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item) => (
                        <tr key={item.id}>
                            <td>{item.productName}</td>
                            <td>{item.quantity}</td>
                            <td>{item.price}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default DataTable;
