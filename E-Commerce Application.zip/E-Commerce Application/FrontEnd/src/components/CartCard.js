import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import api from '../pages/api';

function CartCard({ item, onQuantityChange, onDelete }) {
  const handleQuantityChange = async (change) => {
    const userId = localStorage.getItem('userId');
    try {
      const response = await api.put(`/orders/updateorder/${userId}/${item.productId}?quantity=${change}`);
      onQuantityChange(item.productId, response.data.quantity);
    } catch (error) {
      if(error.response)
      console.error(error.response.data);
    }
  };

  const handleDelete = async () => {
    const userId = localStorage.getItem('userId');
    try {
      await api.delete(`/orders/deleteOrder/${userId}/${item.productId}`);
      onDelete(item.productId);
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  return (
    <div className="card shadow border mx-5 mt-5" style={{ width: '70rem' }}>
      <div className="card-body">
        <div className="row">
          <div className="col-md-3 mb-3 px-5">
            <h6>Product Name:</h6>
            <p>{item.productName}</p>
          </div>

          <div className="col-md-3 mb-3 px-5">
            <h6>Quantity:</h6>
            <div>
              <button className="btn btn-secondary" onClick={() => handleQuantityChange(-1)}>-</button>
              <span className="mx-2">{item.quantity}</span>
              <button className="btn btn-secondary" onClick={() => handleQuantityChange(1)}>+</button>
            </div>
          </div>

          <div className="col-md-3 mb-3 px-5">
            <h6>Price X 1 Quantity:</h6>
            <p>₹{item.price}</p>
          </div>
          <div className="col-md-3 mb-3 px-5">
            <button className="btn btn-danger mt-3" onClick={handleDelete}>Delete</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CartCard;
