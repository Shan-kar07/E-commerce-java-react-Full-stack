import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function CartItems({ order }) {
  return (
    <div className="card shadow border mt-5" style={{ width: '70rem' }}>
      <div className="card-body">
        <div className="row">
          <div className="col-md-4 mb-3 px-5">
            <h6>Product Name: {order.productName}</h6>
          </div>
          <div className="col-md-4 mb-3 px-5">
            <h6>Quantity: {order.quantity}</h6>
          </div>
          <div className="col-md-4 mb-3 px-5">
            <h6>Status: {order.status}</h6>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CartItems;
