import { Route, Routes } from 'react-router-dom';
import './App.css';
import AuthPage from './pages/AuthPage';
import SignIn from './pages/SignIn';
import Signup from './pages/SignUp';
import Home from './pages/Home';
import CartPage from './pages/CartPage';
import OrderHistory from './pages/OrderHistory';
import PaymentPage from './pages/PaymentPage';
import BadRequest from './components/BadRequest';
import AdminPage from './pages/AdminPage';

function App() {
  return (
    <>
    <Routes>
      <Route path='/' element={<AuthPage/>}/>
      <Route path='/register' element={<Signup/>}/>
      <Route path='/login' element={<SignIn/>}/>
      <Route path='/home' element={<Home/>}/>
      <Route path='/cart' element={<CartPage/>}/>
      <Route path='/history' element={<OrderHistory/>}/>
      <Route path='/payment' element={<PaymentPage/>}/>
      <Route path="/bad-request" element={<BadRequest/>} />
      <Route path="/admin" element={<AdminPage />} />
    </Routes>
    </>
  );
}

export default App;
