package com.shankar.project.orderservice.exception;

import com.shankar.project.orderservice.error.ErrorMessage;
import jakarta.validation.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@ControllerAdvice
public class GlobalExceptionHandler {

    // Logger for logging exception details
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @Autowired
    private ErrorMessage errorMessage;


    @ExceptionHandler(OrderAlreadyExits.class)
    public ResponseEntity<?> handleOrderAlreadyExits(OrderAlreadyExits e) {
        // Log the exception message
        log.error("OrderAlreadyExits exception occurred: {}", e.getMessage());

        // Set the error message and return the response
        errorMessage.setMsg(e.getMessage());
        errorMessage.setPresent(LocalDateTime.now());
        return new ResponseEntity<>(errorMessage, HttpStatus.CONFLICT);
    }
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<String> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {
        String errorMessage = "Invalid value for parameter '" + ex.getName() +
                "'. Expected type: " + ex.getRequiredType().getSimpleName();
        log.error("Type Mismatch Error: {}", errorMessage);
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<String> handleGeneralException(Exception ex) {
//        log.error("An error occurred: ");
//        return new ResponseEntity<>("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
//    }

    @ExceptionHandler(OrderNotFoundException.class)
    public ResponseEntity<?> handleOrderNotFoundException(OrderNotFoundException e) {
        // Log the exception message
        log.error("OrderNotFoundException occurred: {}", e.getMessage());

        // Set the error message and return the response
        errorMessage.setMsg(e.getMessage());
        errorMessage.setPresent(LocalDateTime.now());
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoPendingOrderException.class)
    public ResponseEntity<?> handleNoPendingOrderException(NoPendingOrderException e) {
        // Log the exception message
        log.error("NoPendingOrderException occurred: {}", e.getMessage());

        // Set the error message and return the response
        errorMessage.setMsg(e.getMessage());
        errorMessage.setPresent(LocalDateTime.now());
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<?> handleUnauthorizedException(UnauthorizedException e){
        errorMessage.setMsg(e.getMessage());
        errorMessage.setPresent(LocalDateTime.now());
        return new ResponseEntity<>(errorMessage,HttpStatus.UNAUTHORIZED);
    }
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<String> handleConstraintViolation(ConstraintViolationException ex) {
        log.error("Validation error: {}", ex.getMessage());

        String errorMessage = ex.getConstraintViolations()
                .stream()
                .map(violation -> violation.getPropertyPath() + " " + violation.getMessage())
                .collect(Collectors.joining(", "));
        return new ResponseEntity<>("Validation failed: " + errorMessage, HttpStatus.BAD_REQUEST);
    }
}
