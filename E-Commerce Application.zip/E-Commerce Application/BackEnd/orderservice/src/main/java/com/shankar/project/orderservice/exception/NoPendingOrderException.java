package com.shankar.project.orderservice.exception;

public class NoPendingOrderException extends RuntimeException {
    public NoPendingOrderException(String message) {
        super(message);
    }
}
