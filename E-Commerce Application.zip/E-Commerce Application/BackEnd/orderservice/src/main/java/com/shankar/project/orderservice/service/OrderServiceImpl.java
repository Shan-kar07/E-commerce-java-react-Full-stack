package com.shankar.project.orderservice.service;

import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.event.OrderCreatedEvent;
import com.shankar.project.orderservice.exception.NoPendingOrderException;
import com.shankar.project.orderservice.exception.OrderAlreadyExits;
import com.shankar.project.orderservice.exception.OrderNotFoundException;
import com.shankar.project.orderservice.model.Orders;
import com.shankar.project.orderservice.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    // Logger for logging important events and errors
    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private JwtService jwtService;

    private final WebClient webClient;

    private final String inventoryUrl = "http://localhost:8080/inventory/byQuantity/";

    public OrderServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public List<Orders> findAllOrders() {
        log.info("Fetching all orders");
        return orderRepository.findAll();
    }

    public Orders addOrder(Orders order) throws OrderAlreadyExits {
        log.info("Attempting to add order: {}", order);

        // Check if a pending order already exists for the given orderId and product
        Optional<Orders> pendingOrder = orderRepository.findByOrderIdAndProductIdAndStatus(
                order.getOrderId(), order.getProductId(), OrderStatus.PENDING);
        if (pendingOrder.isPresent()) {
            log.warn("A pending order already exists for orderId {} and product {}",
                    order.getOrderId(), order.getProductId());
            throw new OrderAlreadyExits("A pending order already exists for this orderId and product.");
        }

        // Check product quantity before placing order
        Integer productQuantity = getProductQuantity(order.getProductId());
        log.info("Product quantity for product {}: {}", order.getProductId(), productQuantity);
        if (productQuantity == null) {
            log.warn("Product {} is out of stock", order.getProductId());
            throw new OrderAlreadyExits("The Product is out of stock");
        }
        if (productQuantity < order.getQuantity()) {
            log.warn("Not enough quantity for product {}. Requested: {}, Available: {}",
                    order.getProductId(), order.getQuantity(), productQuantity);
            throw new OrderAlreadyExits("Not enough quantity available in inventory");
        }
        order.setStatus(OrderStatus.PENDING);
        // Save the order to the repository
        Orders savedOrder = orderRepository.save(order);
        log.info("Order saved successfully: {}", savedOrder);

        // Map Orders to OrderCreatedEvent
        OrderCreatedEvent orderCreatedEvent = new OrderCreatedEvent(
                savedOrder.getOrderId(),
                savedOrder.getUserId(),
                savedOrder.getProductId(),
                savedOrder.getQuantity(),
                savedOrder.getStatus()
        );
        String token = jwtService.getToken();
        // Send POST request to payments service
        log.info("Sending order to payment service for orderId: {}", savedOrder.getOrderId());
        webClient.post()
                .uri("http://localhost:8080/payments")
                .header("Authorization", "Bearer " + token)
                .body(BodyInserters.fromValue(orderCreatedEvent))
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return savedOrder;
    }

    public List<Orders> orderByName(Integer userId) {
        log.info("Fetching orders for userId: {}", userId);
        List<OrderStatus> statuses = List.of(OrderStatus.FAILED, OrderStatus.COMPLETED);
        return orderRepository.findByUserIdAndStatusIn(userId, statuses);
    }

    public String deleteById(Long id) throws OrderNotFoundException {
        log.info("Attempting to delete order with id: {}", id);
        if (!orderRepository.existsById(id)) {
            log.warn("Order with id {} not found", id);
            throw new OrderNotFoundException("Record not found");
        }
        orderRepository.deleteById(id);
        log.info("Order with id {} deleted successfully", id);
        return orderRepository.existsById(id) ? "Record not deleted" : "Deleted the record successfully";
    }

    public Orders updateOrderStatus(Integer orderId, Integer productId, String updateStatus) throws OrderNotFoundException {
        log.info("Updating order status for orderId: {}, productId: {}", orderId, productId);

        // Find the order with matching orderId, productId, and status PENDING
        Orders order = orderRepository.findByOrderIdAndProductIdAndStatus(orderId, productId, OrderStatus.PENDING)
                .orElseThrow(() -> new OrderNotFoundException("Order not found"));

        // Update the order status
        OrderStatus newStatus = OrderStatus.valueOf(updateStatus.replaceAll("\"", "").trim());
        order.setStatus(newStatus);
        Orders savedOrder = orderRepository.save(order);
        log.info("Order status updated to {}", newStatus);

        // If the order is completed, update the inventory
        if (OrderStatus.COMPLETED.equals(savedOrder.getStatus())) {
            log.info("Order is completed. Updating inventory for productId: {}", savedOrder.getProductId());
            String token = jwtService.getToken();
            log.debug("Using access token to update inventory");
            webClient.put()
                    .uri("http://localhost:8080/inventory/product/" + savedOrder.getProductId() + "/update-stock?amount=" + savedOrder.getQuantity())
                    .header("Authorization", "Bearer " + token)
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();
        } else {
            log.warn("Payment failed for orderId: {}", savedOrder.getOrderId());
        }
        return savedOrder;
    }

    private Integer getProductQuantity(Integer productId) {
        log.debug("Fetching product quantity for productId: {}", productId);

        String url = inventoryUrl + productId;
        log.debug("Requesting product quantity from {}", url);
        String token = jwtService.getToken();
        return webClient.get()
                .uri(url)
                .header("Authorization", "Bearer " + token)
                .retrieve()
                .bodyToMono(Integer.class)
                .block();
    }

    private OrderCreatedEvent mapToOrderCreatedEvent(Orders order) {
        log.debug("Mapping order to OrderCreatedEvent: {}", order);
        OrderCreatedEvent event = new OrderCreatedEvent();
        event.setOrderId(order.getOrderId());
        event.setUserId(order.getUserId());
        event.setProductId(order.getProductId());
        event.setAmount(order.getQuantity());
        event.setStatus(order.getStatus());
        event.setId(order.getId());
        return event;
    }

    public Double calculateTotalPrice(Integer orderId) throws NoPendingOrderException {
        log.info("Calculating total price for pending orders with orderId: {}", orderId);
        List<Orders> pendingOrders = orderRepository.findByOrderIdAndStatus(orderId, OrderStatus.PENDING);

        if (pendingOrders.isEmpty()) {
            log.warn("No pending orders found for orderId: {}", orderId);
            throw new NoPendingOrderException("No pending orders found for order ID: " + orderId);
        }

        double totalPrice = 0;
        for (Orders order : pendingOrders) {
            double orderTotal = order.getQuantity() * order.getPrice();
            totalPrice += orderTotal;
            log.debug("Order ID: {}, Quantity: {}, Unit Price: {}, Order Total: {}",
                    order.getOrderId(), order.getQuantity(), order.getPrice(), orderTotal);
        }

        log.info("Total price calculated: {}", totalPrice);
        return totalPrice;
    }

    public List<Orders> getCartOrders(Integer orderId) {
        return orderRepository.findByOrderIdAndStatus(orderId, OrderStatus.PENDING);
    }

    public Orders updateOrders(Integer orderId, Integer productId, Long quantity) {
        Optional<Orders> order = orderRepository.findByOrderIdAndProductIdAndStatus(orderId, productId, OrderStatus.PENDING);
        if (order.isEmpty())
            throw new OrderNotFoundException("Order not found for the productId " + productId);

        Orders optionalorder = order.get();
        optionalorder.setQuantity(optionalorder.getQuantity() + quantity);
        orderRepository.save(optionalorder);
        return optionalorder;
    }

    public String deleteOrder(Integer orderId, Integer productId) {
        Optional<Orders> order = orderRepository.findByOrderIdAndProductIdAndStatus(orderId, productId, OrderStatus.PENDING);
        if (order.isEmpty())
            throw new OrderNotFoundException("Order not found for the productId " + productId);

        Orders optionalorder = order.get();
        orderRepository.deleteById(optionalorder.getId());
        String token = jwtService.getToken();
        webClient.delete()
                .uri("http://localhost:8080/payments/paymentDelete/" + orderId + "/" + productId)
                .header("Authorization", "Bearer " + token)
                .retrieve()
                .bodyToMono(String.class)
                .block();
        return "Order has been deleted";
    }
    @Transactional
    public void deletefrominventory(Long id) {
        List<Orders> ordersToDelete = orderRepository.findByProductIdAndStatus(id, OrderStatus.PENDING);
        String token = jwtService.getToken();
        for (Orders order : ordersToDelete) {
            Integer productId = order.getProductId();

            webClient.delete()
                    .uri("http://localhost:8080/payments/deletefromorder/" + productId)
                    .header("Authorization", "Bearer " + token)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
        }
        orderRepository.deleteAll(ordersToDelete);
    }
}
