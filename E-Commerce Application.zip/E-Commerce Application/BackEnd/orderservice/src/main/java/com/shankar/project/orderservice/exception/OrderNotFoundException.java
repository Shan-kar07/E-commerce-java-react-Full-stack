package com.shankar.project.orderservice.exception;


import java.time.Clock;
import java.time.LocalDate;

public class OrderNotFoundException extends RuntimeException {
    private LocalDate present;
    public OrderNotFoundException(String message) {
        super(message);
        this.present=LocalDate.now(Clock.systemUTC());
    }
}
