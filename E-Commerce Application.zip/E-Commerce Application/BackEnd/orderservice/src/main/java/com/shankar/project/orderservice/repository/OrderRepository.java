package com.shankar.project.orderservice.repository;

import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface OrderRepository extends JpaRepository<Orders, Long> {


    List<Orders> findByUserId(Integer userId);

    Optional<Orders> findByOrderIdAndProductIdAndStatus(Integer orderId, Integer productId, OrderStatus status);
    List<Orders> findByUserIdAndStatusIn(Integer userId, List<OrderStatus> status);
    List<Orders> findByOrderIdAndStatus(Integer orderId, OrderStatus status);
    List<Orders> findByProductIdAndStatus(Long id, OrderStatus orderStatus);
}
