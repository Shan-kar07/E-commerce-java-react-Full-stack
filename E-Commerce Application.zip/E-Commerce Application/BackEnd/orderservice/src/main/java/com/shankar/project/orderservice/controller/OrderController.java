package com.shankar.project.orderservice.controller;

import com.shankar.project.orderservice.model.Orders;
import com.shankar.project.orderservice.service.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("orders")
public class OrderController {

    private static final Logger log = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private OrderServiceImpl orderServiceImpl;

    public OrderController(OrderServiceImpl orderServiceImpl) {
        this.orderServiceImpl = orderServiceImpl;
    }

    @GetMapping("/allorders")
    public List<Orders> findAllOrders() {
        log.info("Received request to fetch all orders.");
        List<Orders> orders = orderServiceImpl.findAllOrders();
        log.debug("Orders retrieved: {}", orders);
        return orders;
    }

    @PostMapping("/addorders")
    public ResponseEntity<Orders> addOrders(@RequestBody Orders orders) {
        log.info("Received request to add a new order: {}", orders);
        Orders savedOrder = orderServiceImpl.addOrder(orders);
        log.info("Order added successfully with ID: {}", savedOrder.getOrderId());
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
    }

    @GetMapping("/byuserId/{userId}")
    public ResponseEntity<List<Orders>> orderByName(@PathVariable Integer userId) {
        log.info("Received request to fetch orders for userId: {}", userId);
        List<Orders> orders = orderServiceImpl.orderByName(userId);
        log.debug("Orders retrieved for userId {}: {}", userId, orders);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    @DeleteMapping("/deletebyid/{id}")
    public ResponseEntity<String> deleteById(@PathVariable Long id) {
        log.info("Received request to delete order with id: {}", id);
        String response = orderServiceImpl.deleteById(id);
        log.info("Delete operation result for orderId {}: {}", id, response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/{orderId}/orderId/{productId}/updatestate")
    public ResponseEntity<Orders> updateOrderByState(@PathVariable Integer orderId,
                                                     @PathVariable Integer productId,
                                                     @RequestBody String status) {
        log.info("Received request to update order status for orderId: {}, productId: {}", orderId, productId);
        Orders updatedOrder = orderServiceImpl.updateOrderStatus(orderId, productId, status);
        log.info("Order status updated successfully for orderId: {}", orderId);
        return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
    }

    @PostMapping("/makePayment/{orderId}")
    public double calculateTotalPrice(@PathVariable Integer orderId) {
        log.info("Received request to calculate total price for orderId: {}", orderId);
        double totalPrice = orderServiceImpl.calculateTotalPrice(orderId);
        log.info("Total price for orderId {}: {}", orderId, totalPrice);
        return totalPrice;
    }
    @GetMapping("/ordercart/{orderId}")
    public List<Orders> getCartOrders(@PathVariable Integer orderId){
        return  orderServiceImpl.getCartOrders(orderId);
    }
    @PutMapping("/updateorder/{orderId}/{productId}")
    public Orders updateOrders(@PathVariable Integer orderId, @PathVariable Integer productId,@RequestParam Long quantity){
        return orderServiceImpl.updateOrders(orderId,productId,quantity) ;
    }

    @DeleteMapping("/deleteOrder/{orderId}/{productId}")
    public String deleteOrder(@PathVariable Integer orderId, @PathVariable Integer productId){
        return orderServiceImpl.deleteOrder(orderId,productId);
    }
    @DeleteMapping("/deletefrominventory/{id}")
    public void deletefrominventory(@PathVariable Long id){
        orderServiceImpl.deletefrominventory(id);
    }
}
