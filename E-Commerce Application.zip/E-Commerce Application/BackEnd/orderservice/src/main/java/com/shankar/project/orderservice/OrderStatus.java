package com.shankar.project.orderservice;

public enum OrderStatus{
    COMPLETED,
    PENDING,
    FAILED
}