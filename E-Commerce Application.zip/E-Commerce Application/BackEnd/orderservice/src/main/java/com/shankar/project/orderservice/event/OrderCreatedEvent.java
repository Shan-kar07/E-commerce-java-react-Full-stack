package com.shankar.project.orderservice.event;

import com.shankar.project.orderservice.OrderStatus;

public class OrderCreatedEvent {
    private Integer orderId;
    private Integer userId;
    private Integer productId;
    private Long amount;
    private OrderStatus status;
    private Long id;
    private String transactionId;

    public OrderCreatedEvent(Integer orderId, Integer userId, Integer productId, Long amount, OrderStatus status) {
        this.orderId = orderId;
        this.userId = userId;
        this.productId = productId;
        this.amount = amount;
        this.status=status;
    }
    public String getTransId() {
        return transactionId;
    }

    public void setTransId(String transId) {
        this.transactionId = transId;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OrderCreatedEvent() {

    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    // Getters and setters
    public Integer getOrderId() {
        return orderId;
    }
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getProductId() {
        return productId;
    }
    public void setProductId(Integer productId) {
        this.productId = productId;
    }
    public Long getAmount() {
        return amount;
    }
    public void setAmount(Long quantity) {
        this.amount = amount;
    }
}











