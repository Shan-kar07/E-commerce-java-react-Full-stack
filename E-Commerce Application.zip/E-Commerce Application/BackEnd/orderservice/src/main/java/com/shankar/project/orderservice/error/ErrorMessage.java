package com.shankar.project.orderservice.error;

import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
@Component
public class ErrorMessage {
    private String msg;
    private LocalDateTime present;


    public LocalDateTime getPresent() {
        return present;
    }

    public void setPresent(LocalDateTime present) {
        this.present = present;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

