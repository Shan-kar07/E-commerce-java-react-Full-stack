package com.shankar.project.orderservice.service;

import com.shankar.project.orderservice.model.Orders;

import java.util.List;

public interface OrderService {
    public List<Orders> findAllOrders();
    public Orders addOrder(Orders order);
    public List<Orders> orderByName(Integer userId);
    public String deleteById(Long id);
    public Orders updateOrderStatus(Integer orderId, Integer productId, String updateStatus);
    public Double calculateTotalPrice(Integer orderId);
}
