package com.shankar.project.orderservice.exception;

public class OrderAlreadyExits extends RuntimeException{

    public OrderAlreadyExits(String msg){
        super(msg);
    }
}
