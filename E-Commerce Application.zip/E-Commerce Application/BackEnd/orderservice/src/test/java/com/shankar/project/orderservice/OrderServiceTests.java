package com.shankar.project.orderservice.service;

import com.shankar.project.orderservice.OrderStatus;
import com.shankar.project.orderservice.exception.NoPendingOrderException;
import com.shankar.project.orderservice.exception.OrderNotFoundException;
import com.shankar.project.orderservice.model.Orders;
import com.shankar.project.orderservice.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderServiceImplTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private WebClient webClient;

    @InjectMocks
    private OrderServiceImpl orderServiceImpl;

    private Orders order1;
    private Orders order2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Mock WebClient.Builder to return mocked WebClient
        when(webClientBuilder.build()).thenReturn(webClient);

        orderServiceImpl = new OrderServiceImpl(webClientBuilder); // Initialize the orderService with webClientBuilder

        order1 = new Orders();
        order1.setOrderId(1);
        order1.setUserId(1);
        order1.setProductId(101);
        order1.setQuantity(2L);
        order1.setPrice(100L);
        order1.setStatus(OrderStatus.PENDING);

        order2 = new Orders();
        order2.setOrderId(1);
        order2.setUserId(1);
        order2.setProductId(102);
        order2.setQuantity(1L);
        order2.setPrice(200L);
        order2.setStatus(OrderStatus.PENDING);
    }

    @Test
    void testCalculateTotalPrice() throws NoPendingOrderException {
        when(orderRepository.findByOrderIdAndStatus(1, OrderStatus.PENDING)).thenReturn(Arrays.asList(order1, order2));
        Double totalPrice = orderServiceImpl.calculateTotalPrice(1);
        assertEquals(400.0, totalPrice);
        verify(orderRepository, times(1)).findByOrderIdAndStatus(1, OrderStatus.PENDING);
    }

    @Test
    void testDeleteById() throws OrderNotFoundException {
        Long orderId = 1L;
        when(orderRepository.existsById(orderId)).thenReturn(true);
        doNothing().when(orderRepository).deleteById(orderId);

        String result = orderServiceImpl.deleteById(orderId);
        assertEquals("Deleted the record successfully", result);

        verify(orderRepository, times(2)).existsById(orderId);
        verify(orderRepository, times(1)).deleteById(orderId);
    }

    @Test
    void testOrderByName() {
        when(orderRepository.findByUserId(1)).thenReturn(Arrays.asList(order1, order2));
        List<Orders> orders = orderServiceImpl.orderByName(1);
        assertEquals(2, orders.size());
        verify(orderRepository, times(1)).findByUserId(1);
    }
}
