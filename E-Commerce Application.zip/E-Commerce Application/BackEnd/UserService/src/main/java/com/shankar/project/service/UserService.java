package com.shankar.project.service;

import com.shankar.project.dto.OrderDto;
import com.shankar.project.model.UserInfo;
import com.shankar.project.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.MediaType;


@Service
public class UserService {
    @Autowired
    private UserInfoRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    GetToken getToken;

    private final WebClient webClient;

    public UserService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }


    public String addUser(UserInfo userInfo) {
        String name = userInfo.getName();
        UserInfo obj1 = repository.findByName(name).orElse(null);
        System.out.println(obj1);
        if (obj1 == null) {
            userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
            repository.save(userInfo);
            return "Registration Successfully ";
        } else {
            return "This UserName is Already Registered.";
        }
    }

    public String getRoles(String username) {
        UserInfo obj2 = repository.findByName(username).orElse(null);
        if (obj2 != null) {
            return obj2.getRoles();
        }
        return "Not Found";
    }

    public String  userAddOrder(OrderDto orderDto) {
        String token= getToken.getToken();
        webClient.post()
                .uri("http://localhost:8080/orders/addorders")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON) // Specify the Content-Type header
                .body(BodyInserters.fromValue(orderDto))
                .retrieve()
                .bodyToMono(Void.class)
                .block();

        return "Order placed by user";
    }
}
