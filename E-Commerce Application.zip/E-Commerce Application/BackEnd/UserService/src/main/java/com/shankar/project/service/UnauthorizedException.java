package com.shankar.project.service;

public class UnauthorizedException extends RuntimeException {

    public UnauthorizedException(String message)
    {
        super(message);
    }
}
