package com.shankar.project.paymentservice.controller;

import com.shankar.project.paymentservice.model.Payment;
import com.shankar.project.paymentservice.service.PaymentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("payments")
public class PaymentController {

    // Logger for logging important events and errors
    private static final Logger log = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentServiceImpl paymentServiceImpl;

    public PaymentController(PaymentServiceImpl paymentServiceImpl) {
        this.paymentServiceImpl = paymentServiceImpl;
    }

    @PostMapping
    public ResponseEntity<Payment> initiatePayment(@RequestBody Payment payment) {
        log.info("Received request to initiate payment: {}", payment);
        Payment initiatedPayment = paymentServiceImpl.initiatePayment(payment);
        log.info("Payment initiated successfully with ID: {}", initiatedPayment.getId());
        return new ResponseEntity<>(initiatedPayment, HttpStatus.CREATED);
    }

    @GetMapping("/order/{orderId}")
    public ResponseEntity<List<Payment>> getPaymentByOrder(@PathVariable Integer orderId) {
        log.info("Received request to fetch payments for orderId: {}", orderId);
        List<Payment> payments = paymentServiceImpl.getPaymentByOrderId(orderId);
        log.debug("Payments retrieved for orderId {}: {}", orderId, payments);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    @PutMapping("/{orderId}/status")
    public ResponseEntity<List<Payment>> updatePaymentStatus(@PathVariable Integer orderId, @RequestBody String status) {
        log.info("Received request to update payment status for orderId: {}", orderId);
        List<Payment> updatedPayment = paymentServiceImpl.updatePaymentStatusByOrderId(orderId, status);
        log.info("Payment status updated successfully for orderId: {}", orderId);
        return new ResponseEntity<>(updatedPayment, HttpStatus.OK);
    }
    @DeleteMapping("/paymentDelete/{orderId}/{paymentId}")
    public String paymentDeleteByOrder(@PathVariable Integer orderId,@PathVariable Integer paymentId){
        return  paymentServiceImpl.paymentDeleteByOrder(orderId,paymentId);
    }
    @DeleteMapping("/deletefromorder/{productId}")
    public  void paymentDelete(@PathVariable Integer productId){
        paymentServiceImpl.paymentDelete(productId);
    }
}
