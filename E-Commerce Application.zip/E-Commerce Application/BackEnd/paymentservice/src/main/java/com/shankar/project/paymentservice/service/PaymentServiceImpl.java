package com.shankar.project.paymentservice.service;

import com.shankar.project.paymentservice.PaymentStatus;
import com.shankar.project.paymentservice.event.PaymentCompleteEvent;
import com.shankar.project.paymentservice.exception.PaymentServiceException;
import com.shankar.project.paymentservice.model.Payment;
import com.shankar.project.paymentservice.repository.PaymentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Import SLF4J Logger
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private JwtService jwtService;

    private final WebClient webClient;

    // Initialize the Logger
    private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);

    @Autowired
    public PaymentServiceImpl(WebClient.Builder webClientBuilder) {
        // Build the WebClient instance
        this.webClient = webClientBuilder.build();
    }


    public Payment initiatePayment(Payment payment) {
        logger.debug("Initiating payment for order ID: {}", payment.getOrderId());

        // Set the payment status to PENDING
        payment.setStatus(PaymentStatus.PENDING);

        // Save the payment to the repository
        Payment savedPayment = paymentRepository.save(payment);

        logger.info("Payment initiated and saved with ID: {}", savedPayment.getId());
        return savedPayment;
    }


    public List<Payment> getPaymentByOrderId(Integer orderId) {
        logger.debug("Fetching payments for order ID: {}", orderId);

        // Retrieve payments from the repository based on the order ID
        return paymentRepository.findByOrderId(orderId);
    }


    public List<Payment> updatePaymentStatusByOrderId(Integer orderId, String status) {
        logger.debug("Updating payment status for order ID: {} to status: {}", orderId, status);

        // Find all pending payments for the given order ID
        List<Payment> payments = paymentRepository.findByOrderIdAndStatus(orderId, PaymentStatus.PENDING);
        if (payments.isEmpty()) {
            logger.error("No pending payments found for order ID: {}", orderId);
            throw new PaymentServiceException("No payments found for the given order ID.");
        }

        List<Payment> updatedPayments = new ArrayList<>();
        String trimmedStatus = status.replaceAll("\"", "").trim();
        PaymentStatus updateStatus = PaymentStatus.valueOf(trimmedStatus);

        // Update each payment's status and transaction ID
        for (Payment payment : payments) {
            payment.setStatus(updateStatus);
            payment.setTransactionId(generateRandomTransactionId());

            // Save the updated payment
            Payment updatedPayment = paymentRepository.save(payment);
            if (updatedPayment == null) {
                logger.error("Failed to update payment with ID: {}", payment.getId());
                throw new PaymentServiceException("Failed to update payment with ID: " + payment.getId());
            }
            logger.info("Payment with ID: {} updated to status: {}", updatedPayment.getId(), updatedPayment.getStatus());
            updatedPayments.add(updatedPayment);

            // Create and publish a payment completion event
            PaymentCompleteEvent paymentCompleteEvent = new PaymentCompleteEvent();
            paymentCompleteEvent.setStatus(updatedPayment.getStatus());
            paymentCompleteEvent.setOrderId(updatedPayment.getOrderId());
            paymentCompleteEvent.setProductId(updatedPayment.getProductId());

            // Update the order state based on the payment event
            updateOrderState(paymentCompleteEvent);
        }

        return updatedPayments;
    }


    private void updateOrderState(PaymentCompleteEvent paymentCompleteEvent) {
                    logger.debug("Updating order state for order ID: {}, product ID: {}",
                    paymentCompleteEvent.getOrderId(), paymentCompleteEvent.getProductId());
                    // Send a PUT request to the order service to update the order state
                    String token= jwtService.getToken();
                    webClient.put()
                            .uri("http://localhost:8080/orders/{orderId}/orderId/{productId}/updatestate",
                                    paymentCompleteEvent.getOrderId(), paymentCompleteEvent.getProductId())
                            .header("Authorization", "Bearer " + token)
                            .body(BodyInserters.fromValue("\"" + paymentCompleteEvent.getStatus().name() + "\""))
                            .retrieve()
                            .bodyToMono(Void.class)
                            .block();

    }

    public static String generateRandomTransactionId() {
        logger.debug("Generating a random transaction ID.");

        Random random = new Random();
        int numericId = 1000000 + random.nextInt(9000000); // Random number between 1000000 and 9999999
        int numericSuffix = 1 + random.nextInt(10);        // Random number between 1 and 10

        String transactionId = String.format("TRANS_%d_%d", numericId, numericSuffix);
        logger.debug("Generated transaction ID: {}", transactionId);
        return transactionId;
    }

    public String paymentDeleteByOrder(Integer orderId, Integer paymentId) {
        Payment payment=paymentRepository.findByOrderIdAndProductIdAndStatus(orderId,paymentId,PaymentStatus.PENDING);
        paymentRepository.deleteById(payment.getId());
        return "Delete the payment";
    }
    @Transactional
    public void paymentDelete(Integer productId) {
        paymentRepository.deleteByProductIdAndStatus(productId,PaymentStatus.PENDING);
    }
}
