package com.shankar.project.paymentservice.service;

import com.shankar.project.paymentservice.model.Payment;

import java.util.List;

public interface PaymentService {
    public Payment initiatePayment(Payment payment);
    public List<Payment> getPaymentByOrderId(Integer orderId);
    public List<Payment> updatePaymentStatusByOrderId(Integer orderId, String status);
}
