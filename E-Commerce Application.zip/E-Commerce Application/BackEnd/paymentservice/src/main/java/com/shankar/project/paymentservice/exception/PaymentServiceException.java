package com.shankar.project.paymentservice.exception;

public class PaymentServiceException extends RuntimeException {
    private String message;

    public PaymentServiceException(String message) {
        super(message);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

