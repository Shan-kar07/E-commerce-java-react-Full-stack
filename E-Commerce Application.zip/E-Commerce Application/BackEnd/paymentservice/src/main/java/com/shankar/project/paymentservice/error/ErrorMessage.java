package com.shankar.project.paymentservice.error;

import java.time.LocalDate;

public class ErrorMessage {
    private String message;
    private LocalDate present;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDate getPresent() {
        return present;
    }

    public void setPresent(LocalDate present) {
        this.present = present;
    }
}
