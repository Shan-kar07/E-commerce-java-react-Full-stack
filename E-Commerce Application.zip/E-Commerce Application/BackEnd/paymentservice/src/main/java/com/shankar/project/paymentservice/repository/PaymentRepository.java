package com.shankar.project.paymentservice.repository;

import com.shankar.project.paymentservice.PaymentStatus;
import com.shankar.project.paymentservice.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByOrderIdAndStatus(Integer orderId, PaymentStatus status);
    List<Payment> findByOrderId(Integer orderId);
    Payment findByOrderIdAndProductIdAndStatus(Integer orderId,Integer paymentId,PaymentStatus status);

    void deleteByProductIdAndStatus(Integer productId, PaymentStatus paymentStatus);
}
