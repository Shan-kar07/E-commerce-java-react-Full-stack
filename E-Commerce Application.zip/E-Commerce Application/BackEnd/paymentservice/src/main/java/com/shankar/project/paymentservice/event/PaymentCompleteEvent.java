package com.shankar.project.paymentservice.event;

import com.shankar.project.paymentservice.PaymentStatus;


public class PaymentCompleteEvent {
    private PaymentStatus status;
    private Integer orderId;
    private Integer productId;

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }
}
