package com.shankar.project.inventoryservice.service;

import com.shankar.project.inventoryservice.model.Inventory;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface InventoryService {
    public Inventory updateStock(Long productId, Long quantity);
    public ResponseEntity<?> getInventoryByProduct(Long productId);
    public Inventory putProduct(Inventory inventory);
    public Inventory updateStockUp(Long productId, Long quantity);
    public List<Inventory> searchProducts(String name, String category, Double minPrice, Double maxPrice);
    public List<Inventory> getAll();
    public Integer findQuantityByProductId(Long productId);
}
