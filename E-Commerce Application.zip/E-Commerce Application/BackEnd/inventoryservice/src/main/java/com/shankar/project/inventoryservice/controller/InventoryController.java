package com.shankar.project.inventoryservice.controller;

import com.shankar.project.inventoryservice.model.Inventory;
import com.shankar.project.inventoryservice.service.InventoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    // Logger for logging important events and errors
    private static final Logger log = LoggerFactory.getLogger(InventoryController.class);

    @Autowired
    private InventoryServiceImpl inventoryServiceImpl;


    @GetMapping("/product/{productId}")
    public ResponseEntity<?> getInventoryByProduct(@PathVariable("productId") Long productId) {
        log.info("Received request to get inventory for productId: {}", productId);
        return new ResponseEntity<>(inventoryServiceImpl.getInventoryByProduct(productId), HttpStatus.OK);
    }


    @PutMapping("/product/{productId}/update-stock")
    public ResponseEntity<Inventory> updateStock(@PathVariable Long productId, @RequestParam Long amount) {
        log.info("Received request to decrease stock for productId: {} by amount: {}", productId, amount);
        Inventory updatedInventory = inventoryServiceImpl.updateStock(productId, amount);
        log.info("Stock updated successfully for productId: {}", productId);
        return new ResponseEntity<>(updatedInventory, HttpStatus.OK);
    }

    @PutMapping("/product/{productId}/update-stockup")
    public ResponseEntity<Inventory> updateStockup(@PathVariable Long productId, @RequestParam Long quantity) {
        log.info("Received request to increase stock for productId: {} by quantity: {}", productId, quantity);
        Inventory updatedInventory = inventoryServiceImpl.updateStockUp(productId, quantity);
        log.info("Stock increased successfully for productId: {}", productId);
        return new ResponseEntity<>(updatedInventory, HttpStatus.OK);
    }

    @PostMapping("/putproduct")
    public ResponseEntity<Inventory> putproduct(@RequestBody Inventory inventory) {
        log.info("Received request to add new product to inventory: {}", inventory);
        Inventory savedInventory = inventoryServiceImpl.putProduct(inventory);
        log.info("Product added successfully with productId: {}", savedInventory.getProductId());
        return new ResponseEntity<>(savedInventory, HttpStatus.CREATED);
    }

    @GetMapping("/search")
    public List<Inventory> searchBooks(@RequestParam(required = false) String name,
                                       @RequestParam(required = false) String category,
                                       @RequestParam(required = false) Double minPrice,
                                       @RequestParam(required = false) Double maxPrice) {
        log.info("Received request to search products with name: {}, category: {}, minPrice: {}, maxPrice: {}",
                name, category, minPrice, maxPrice);
        List<Inventory> products = inventoryServiceImpl.searchProducts(name, category, minPrice, maxPrice);
        log.debug("Search results: {}", products);
        return products;
    }

    @GetMapping("/all")
    public List<Inventory> getAll() {
        log.info("Received request to get all inventory items");
        List<Inventory> inventories = inventoryServiceImpl.getAll();
        log.debug("All inventory items retrieved: {}", inventories);
        return inventories;
    }

    @GetMapping("/byQuantity/{productId}")
    public Integer getQuantity(@PathVariable Long productId) {
        log.info("Received request to get quantity for productId: {}", productId);
        Integer quantity = inventoryServiceImpl.findQuantityByProductId(productId);
        log.debug("Quantity retrieved for productId {}: {}", productId, quantity);
        return quantity;
    }
    @DeleteMapping("/product/{id}")
    public void deleteProductById(@PathVariable Long id){
         inventoryServiceImpl.deleteProductById(id);
    }

}
