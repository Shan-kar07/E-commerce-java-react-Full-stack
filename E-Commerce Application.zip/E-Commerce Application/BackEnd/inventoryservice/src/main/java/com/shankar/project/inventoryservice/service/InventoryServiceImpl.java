package com.shankar.project.inventoryservice.service;

import com.shankar.project.inventoryservice.model.Inventory;
import com.shankar.project.inventoryservice.repository.InventoryRepository;
import com.shankar.project.inventoryservice.exception.ProductNotFoundException;
import com.shankar.project.inventoryservice.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;

@Service
public class InventoryServiceImpl implements InventoryService {

    private final WebClient webClient;

    @Autowired
    private JwtService jwtService;

    private static final Logger log = LoggerFactory.getLogger(InventoryServiceImpl.class);

    public InventoryServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    @Autowired
    private InventoryRepository inventoryRepository;


    public Inventory updateStock(Long productId, Long amount) {
        log.info("Attempting to decrease stock for productId: {} by amount: {}", productId, amount);
        Optional<Inventory> inventoryOptional = inventoryRepository.findByProductId(productId);
        if (inventoryOptional.isPresent()) {
            Inventory inventory = inventoryOptional.get();
            inventory.setStockLevel(inventory.getStockLevel() - amount);
            Inventory updatedInventory = inventoryRepository.save(inventory);
            log.info("Stock decreased successfully for productId: {}. New stock level: {}", productId, updatedInventory.getStockLevel());
            return updatedInventory;
        }
        log.error("Product not found with productId: {}", productId);
        throw new ProductNotFoundException("Product not found");
    }


    public ResponseEntity<?> getInventoryByProduct(Long productId) {
        log.info("Fetching inventory for productId: {}", productId);
        Optional<Inventory> optionalInventory = inventoryRepository.findByProductId(productId);
        if (optionalInventory.isEmpty()) {
            log.error("Product not found with productId: {}", productId);
            throw new ProductNotFoundException("There is no product with ID: " + productId + " present in the Inventory");
        } else {
            log.info("Inventory retrieved successfully for productId: {}", productId);
            return new ResponseEntity<>(optionalInventory, HttpStatus.OK);
        }
    }


    public Inventory putProduct(Inventory inventory) {
        log.info("Adding new product to inventory: {}", inventory);
        inventory.setProductId((long) (Math.random() * 90000000L) + 10000000L);
        Inventory savedInventory = inventoryRepository.save(inventory);
        log.info("Product added successfully with productId: {}", savedInventory.getProductId());
        return savedInventory;
    }


    public Inventory updateStockUp(Long productId, Long quantity) {
        log.info("Updating stock level for productId: {} to quantity: {}", productId, quantity);
        Optional<Inventory> inventoryOptional = inventoryRepository.findByProductId(productId);
        if (inventoryOptional.isPresent()) {
            Inventory inventory = inventoryOptional.get();
            Long presentQuantity=inventory.getStockLevel();
            inventory.setStockLevel(presentQuantity+quantity);
            Inventory updatedInventory = inventoryRepository.save(inventory);
            log.info("Stock level updated successfully for productId: {}. New stock level: {}", productId, updatedInventory.getStockLevel());
            return updatedInventory;
        }
        log.error("Product not found with productId: {}", productId);
        throw new ProductNotFoundException("Product not found");
    }

    public List<Inventory> searchProducts(String name, String category, Double minPrice, Double maxPrice) {
        log.info("Searching products with name: '{}', category: '{}', minPrice: {}, maxPrice: {}",
                name, category, minPrice, maxPrice);
        List<Inventory> products = inventoryRepository.searchProduct(name, category, minPrice, maxPrice);
        log.debug("Search results: {}", products);
        return products;
    }


    public List<Inventory> getAll() {
        log.info("Fetching all products from inventory");
        List<Inventory> inventories = inventoryRepository.findAll();
        log.debug("All inventory items retrieved: {}", inventories);
        return inventories;
    }


    public Integer findQuantityByProductId(Long productId) {
        log.info("Retrieving quantity for productId: {}", productId);
        Integer quantity = inventoryRepository.findQuantityByProductId(productId);
        log.debug("Quantity retrieved for productId {}: {}", productId, quantity);
        return quantity;
    }

    public void deleteProductById(Long id) {
        deleteInOrder(id);
        inventoryRepository.deleteById(id);
    }

    public void deleteInOrder(Long id){
       Optional<Inventory> optionalInventory=inventoryRepository.findById(id);
       Inventory inventory=optionalInventory.get();
       String token = jwtService.getToken();
       webClient.delete()
                .uri("http://localhost:8080/orders/deletefrominventory/"+inventory.getProductId())
                .header("Authorization", "Bearer " + token)
                .retrieve()
                .bodyToMono(Void.class)
                .block();
    }
}
