package com.shankar.project.inventoryservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.*;
import lombok.Data;


@Entity
@Table(name = "inventory")
@Data
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private Long productId;

    @NotNull(message = "Price cannot be null.")
    @Min(value = 0, message = "Price must be zero or positive.")
    private Long price;

    @NotBlank(message = "Name cannot be blank.")
    @Size(max = 100, message = "Name must be at most 100 characters.")
    private String name;

    @NotNull(message = "Stock level cannot be null.")
    @Min(value = 0, message = "Stock level must be zero or positive.")
    private Long stockLevel;

    @NotBlank(message = "Category cannot be blank.")
    private String category;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getStockLevel() {
        return stockLevel;
    }

    public void setStockLevel(Long stockLevel) {
        this.stockLevel = stockLevel;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
