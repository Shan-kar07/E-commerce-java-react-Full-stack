package com.shankar.project.inventoryservice.repository;

import com.shankar.project.inventoryservice.model.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    Optional<Inventory> findByProductId(Long productId);
    @Query("SELECT b FROM Inventory b WHERE " + "(:name IS NULL OR b.name LIKE %:name%) AND "
            + "(:category IS NULL OR b.category LIKE %:category%) AND "
            + "(:minPrice IS NULL OR b.price >= :minPrice) AND " + "(:maxPrice IS NULL OR b.price <= :maxPrice)")
    List<Inventory> searchProduct(@Param("name") String name, @Param("category") String category,
                                @Param("minPrice") Double minPrice, @Param("maxPrice") Double maxPrice);
    @Query("SELECT i.stockLevel FROM Inventory i WHERE i.productId = :productId")
    Integer findQuantityByProductId(@Param("productId") Long productId);
}
