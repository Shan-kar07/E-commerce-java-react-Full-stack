package com.shankar.project.inventoryservice.error;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class ErrorMessage {
    private String message;
    private LocalDateTime present;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getPresent() {
        return present;
    }

    public void setPresent(LocalDateTime present) {
        this.present = present;
    }
}
