package com.shankar.project.inventoryservice;

import com.shankar.project.inventoryservice.model.Inventory;
import com.shankar.project.inventoryservice.repository.InventoryRepository;
import com.shankar.project.inventoryservice.service.InventoryServiceImpl;
import com.shankar.project.inventoryservice.exception.ProductNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class InventoryserviceApplicationTests {

	@Mock
	private InventoryRepository inventoryRepository;

	@InjectMocks
	private InventoryServiceImpl inventoryServiceImpl;

	@Test
	void contextLoads() {
	}

	@Test
	public void testUpdateStock_ProductExists() {
		Inventory inventory = new Inventory();
		inventory.setProductId(1L);
		inventory.setStockLevel(10L);
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.of(inventory));
		when(inventoryRepository.save(inventory)).thenReturn(inventory);

		Inventory updatedInventory = inventoryServiceImpl.updateStock(1L, 5L);

		assertNotNull(updatedInventory);
		assertEquals(5, updatedInventory.getStockLevel());
	}

	@Test
	public void testUpdateStock_ProductNotFound() {
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.empty());

		assertThrows(ProductNotFoundException.class, () -> inventoryServiceImpl.updateStock(1L, 5L));
	}

	@Test
	public void testGetInventoryByProduct_ProductExists() {
		Inventory inventory = new Inventory();
		inventory.setProductId(1L);
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.of(inventory));

		ResponseEntity<?> response = inventoryServiceImpl.getInventoryByProduct(1L);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertTrue(response.getBody() instanceof Optional);
		assertEquals(inventory, ((Optional<?>) response.getBody()).orElse(null));
	}

	@Test
	public void testGetInventoryByProduct_ProductNotFound() {
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.empty());

		assertThrows(ProductNotFoundException.class, () -> inventoryServiceImpl.getInventoryByProduct(1L));
	}

	@Test
	public void testPutProduct() {
		Inventory inventory = new Inventory();
		when(inventoryRepository.save(inventory)).thenReturn(inventory);

		Inventory savedInventory = inventoryServiceImpl.putProduct(inventory);

		assertEquals(inventory, savedInventory);
	}

	@Test
	public void testUpdateStockUp_ProductExists() {
		Inventory inventory = new Inventory();
		inventory.setProductId(1L);
		inventory.setStockLevel(10L);
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.of(inventory));
		when(inventoryRepository.save(inventory)).thenReturn(inventory);

		Inventory updatedInventory = inventoryServiceImpl.updateStockUp(1L, 20L);

		assertNotNull(updatedInventory);
		assertEquals(20, updatedInventory.getStockLevel());
	}

	@Test
	public void testUpdateStockUp_ProductNotFound() {
		when(inventoryRepository.findByProductId(1L)).thenReturn(Optional.empty());

		assertThrows(ProductNotFoundException.class, () -> inventoryServiceImpl.updateStockUp(1L, 20L));
	}

	@Test
	public void testSearchProducts_Found() {
		Inventory inventory = new Inventory();
		inventory.setProductId(1L);
		List<Inventory> inventoryList = Collections.singletonList(inventory);
		when(inventoryRepository.searchProduct("name", "category", 10.0, 20.0)).thenReturn(inventoryList);

		List<Inventory> result = inventoryServiceImpl.searchProducts("name", "category", 10.0, 20.0);

		assertEquals(inventoryList, result);
	}

	@Test
	public void testSearchProducts_NotFound() {
		List<Inventory> inventoryList = Collections.emptyList();
		when(inventoryRepository.searchProduct("name", "category", 10.0, 20.0)).thenReturn(inventoryList);

		List<Inventory> result = inventoryServiceImpl.searchProducts("name", "category", 10.0, 20.0);

		assertEquals(inventoryList, result);
	}

	@Test
	public void testGetAll_ProductsFound() {
		Inventory inventory = new Inventory();
		List<Inventory> inventoryList = Collections.singletonList(inventory);
		when(inventoryRepository.findAll()).thenReturn(inventoryList);

		List<Inventory> result = inventoryServiceImpl.getAll();

		assertEquals(inventoryList, result);
	}

	@Test
	public void testGetAll_NoProductsFound() {
		List<Inventory> inventoryList = Collections.emptyList();
		when(inventoryRepository.findAll()).thenReturn(inventoryList);

		List<Inventory> result = inventoryServiceImpl.getAll();

		assertEquals(inventoryList, result);
	}

	@Test
	public void testFindQuantityByProductId_ProductExists() {
		when(inventoryRepository.findQuantityByProductId(1L)).thenReturn(10);

		Integer quantity = inventoryServiceImpl.findQuantityByProductId(1L);

		assertEquals(10, quantity);
	}

	@Test
	public void testFindQuantityByProductId_ProductNotFound() {
		when(inventoryRepository.findQuantityByProductId(1L)).thenReturn(null);

		Integer quantity = inventoryServiceImpl.findQuantityByProductId(1L);

		assertNull(quantity);
	}
}
